import { useEffect, useMemo, useState } from 'react';
import DataFormModal from '../components/DataFormModal.jsx';
import DataTable from '../components/DataTable.jsx';
import { createRecord, deleteRecord, getResourceUrl, listRecords, updateRecord } from '../api/http.js';

export default function ResourcePage({ resource }) {
  const [records, setRecords] = useState([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');
  const [query, setQuery] = useState('');
  const [modalState, setModalState] = useState(null);

  const visibleRecords = useMemo(() => {
    if (!query.trim()) return records;
    const keyword = query.toLowerCase();
    return records.filter((record) =>
      resource.fields.some((field) => String(record[field.name] || '').toLowerCase().includes(keyword))
    );
  }, [query, records, resource.fields]);

  async function loadData() {
    setLoading(true);
    setError('');
    try {
      setRecords(await listRecords(resource));
    } catch (err) {
      setError(err?.response?.data?.message || err.message || 'Unable to load records.');
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    loadData();
  }, [resource.key]);

  async function handleSave(payload) {
    setSaving(true);
    setError('');
    try {
      if (modalState.mode === 'create') {
        await createRecord(resource, payload);
      } else {
        await updateRecord(resource, modalState.record, payload);
      }
      setModalState(null);
      await loadData();
    } catch (err) {
      setError(err?.response?.data?.message || err.message || 'Unable to save record.');
    } finally {
      setSaving(false);
    }
  }

  async function handleDelete(record) {
    const confirmed = window.confirm(`Delete this ${resource.model} record?`);
    if (!confirmed) return;

    setError('');
    try {
      await deleteRecord(resource, record);
      await loadData();
    } catch (err) {
      setError(err?.response?.data?.message || err.message || 'Unable to delete record.');
    }
  }

  return (
    <div>
      <div className="page-header">
        <div>
          <p className="eyebrow">{resource.model}</p>
          <h2>{resource.title}</h2>
          <p className="text-muted mb-0">{resource.description}</p>
        </div>
        <button className="btn btn-primary" onClick={() => setModalState({ mode: 'create' })}>
          Add Record
        </button>
      </div>

      <div className="toolbar">
        <input
          className="form-control"
          value={query}
          placeholder="Search records"
          onChange={(event) => setQuery(event.target.value)}
        />
        <button className="btn btn-outline-secondary" onClick={loadData}>
          Refresh
        </button>
      </div>

      <div className="endpoint-line">
        <span>Endpoint</span>
        <code>{getResourceUrl(resource)}</code>
      </div>

      {error && <div className="alert alert-danger">{error}</div>}

      <DataTable
        resource={resource}
        records={visibleRecords}
        loading={loading}
        onEdit={(record) => setModalState({ mode: 'edit', record })}
        onDelete={handleDelete}
      />

      {modalState && (
        <DataFormModal
          mode={modalState.mode}
          resource={resource}
          record={modalState.record}
          onClose={() => setModalState(null)}
          onSubmit={handleSave}
          saving={saving}
        />
      )}
    </div>
  );
}
