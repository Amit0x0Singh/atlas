import { NavLink, Outlet } from 'react-router-dom';
import { resources } from '../data/resources.js';

export default function AdminLayout() {
  return (
    <div className="admin-shell">
      <aside className="sidebar">
        <div className="brand">
          <span className="brand-mark">IA</span>
          <div>
            <h1>Inventory Admin</h1>
            <p>PostgreSQL data panel</p>
          </div>
        </div>

        <nav className="nav flex-column">
          <NavLink to="/" end className={({ isActive }) => `nav-link ${isActive ? 'active' : ''}`}>
            Dashboard
          </NavLink>
          {resources.map((resource) => (
            <NavLink
              key={resource.key}
              to={`/${resource.path}`}
              className={({ isActive }) => `nav-link ${isActive ? 'active' : ''}`}
            >
              {resource.title}
            </NavLink>
          ))}
        </nav>
      </aside>

      <main className="content">
        <Outlet />
      </main>
    </div>
  );
}
