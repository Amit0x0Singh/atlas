import { Link } from 'react-router-dom';
import { resources } from '../data/resources.js';

export default function Dashboard() {
  return (
    <div>
      <div className="page-header">
        <div>
          <p className="eyebrow">Admin Panel</p>
          <h2>Application Data</h2>
          <p className="text-muted mb-0">Open any schema page to view, add, edit, or delete records.</p>
        </div>
      </div>

      <div className="resource-grid">
        {resources.map((resource) => (
          <Link to={`/${resource.path}`} className="resource-card" key={resource.key}>
            <span>{resource.model}</span>
            <h3>{resource.title}</h3>
            <p>{resource.description}</p>
          </Link>
        ))}
      </div>
    </div>
  );
}
