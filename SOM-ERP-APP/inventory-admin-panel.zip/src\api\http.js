import axios from 'axios';

const baseURL = import.meta.env.VITE_API_BASE_URL || 'http://localhost:5000/api';

export const http = axios.create({
  baseURL,
  headers: {
    'Content-Type': 'application/json'
  }
});

function joinUrl(base, path) {
  if (!path) return base;
  if (/^https?:\/\//i.test(path)) return path;
  return `${base.replace(/\/$/, '')}/${path.replace(/^\//, '')}`;
}

export function getResourceUrl(resource) {
  const override = import.meta.env[resource.envKey];
  return joinUrl(baseURL, override || resource.defaultEndpoint);
}

export function getRecordId(record, resource) {
  if (!record) return '';

  if (Array.isArray(resource.idField)) {
    return resource.idField.map((field) => encodeURIComponent(record[field])).join('/');
  }

  return encodeURIComponent(record[resource.idField]);
}

export async function listRecords(resource) {
  const { data } = await axios.get(getResourceUrl(resource));
  return Array.isArray(data) ? data : data?.data || data?.records || [];
}

export async function createRecord(resource, payload) {
  const { data } = await axios.post(getResourceUrl(resource), payload);
  return data;
}

export async function updateRecord(resource, record, payload) {
  const url = `${getResourceUrl(resource)}/${getRecordId(record, resource)}`;
  const { data } = await axios.put(url, payload);
  return data;
}

export async function deleteRecord(resource, record) {
  const url = `${getResourceUrl(resource)}/${getRecordId(record, resource)}`;
  const { data } = await axios.delete(url);
  return data;
}
