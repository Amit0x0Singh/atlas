const field = (name, label, type = 'text', options = {}) => ({ name, label, type, ...options });

export const resources = [
  {
    key: 'rmMaster',
    title: 'Raw Material Master',
    model: 'RmMaster',
    path: 'rm-master',
    envKey: 'VITE_RM_MASTER_URL',
    defaultEndpoint: '/rm-master',
    idField: 'itemCode',
    description: 'Raw material catalogue, unit, and tracking type.',
    fields: [
      field('itemCode', 'Item Code'),
      field('itemName', 'Item Name'),
      field('uom', 'UOM'),
      field('trackingType', 'Tracking Type', 'select', { options: ['PACK', 'BULK'] }),
      field('createdAt', 'Created At', 'datetime-local', { readOnly: true }),
      field('updatedAt', 'Updated At', 'datetime-local', { readOnly: true })
    ]
  },
  {
    key: 'bulkLocation',
    title: 'Bulk Locations',
    model: 'BulkLocation',
    path: 'bulk-location',
    envKey: 'VITE_BULK_LOCATION_URL',
    defaultEndpoint: '/bulk-location',
    idField: 'locationId',
    description: 'Physical storage locations for bulk raw materials.',
    fields: [
      field('locationId', 'Location ID'),
      field('locationName', 'Location Name'),
      field('itemCode', 'Item Code'),
      field('itemName', 'Item Name'),
      field('uom', 'UOM'),
      field('createdAt', 'Created At', 'datetime-local', { readOnly: true })
    ]
  },
  {
    key: 'bulkLotEntry',
    title: 'Bulk Lot Entries',
    model: 'BulkLotEntry',
    path: 'bulk-lot-entry',
    envKey: 'VITE_BULK_LOT_ENTRY_URL',
    defaultEndpoint: '/bulk-lot-entry',
    idField: 'id',
    description: 'Individual lot records within a bulk location.',
    fields: [
      field('id', 'ID', 'text', { readOnly: true }),
      field('locationId', 'Location ID'),
      field('itemCode', 'Item Code'),
      field('itemName', 'Item Name'),
      field('lotNo', 'Lot No'),
      field('supplier', 'Supplier'),
      field('invoiceNo', 'Invoice No'),
      field('receivedDate', 'Received Date', 'date'),
      field('receivedQty', 'Received Qty', 'number'),
      field('remainingQty', 'Remaining Qty', 'number'),
      field('uom', 'UOM'),
      field('status', 'Status', 'select', { options: ['ACTIVE', 'EXHAUSTED'] }),
      field('createdAt', 'Created At', 'datetime-local', { readOnly: true }),
      field('updatedAt', 'Updated At', 'datetime-local', { readOnly: true })
    ]
  },
  {
    key: 'bulkLotSequence',
    title: 'Bulk Lot Sequence',
    model: 'BulkLotSequence',
    path: 'bulk-lot-sequence',
    envKey: 'VITE_BULK_LOT_SEQUENCE_URL',
    defaultEndpoint: '/bulk-lot-sequence',
    idField: ['itemCode', 'year'],
    description: 'Auto-increment sequence for bulk lot numbers per item/year.',
    fields: [
      field('itemCode', 'Item Code'),
      field('year', 'Year', 'number'),
      field('seq', 'Sequence', 'number')
    ]
  },
  {
    key: 'lotSequence',
    title: 'Lot Sequence',
    model: 'LotSequence',
    path: 'lot-sequence',
    envKey: 'VITE_LOT_SEQUENCE_URL',
    defaultEndpoint: '/lot-sequence',
    idField: ['itemCode', 'year'],
    description: 'Auto-increment sequence for pack lot numbers per item/year.',
    fields: [
      field('itemCode', 'Item Code'),
      field('year', 'Year', 'number'),
      field('seq', 'Sequence', 'number')
    ]
  },
  {
    key: 'printMaster',
    title: 'Print Master',
    model: 'PrintMaster',
    path: 'print-master',
    envKey: 'VITE_PRINT_MASTER_URL',
    defaultEndpoint: '/print-master',
    idField: 'packId',
    description: 'Label and pack records generated before inward.',
    fields: [
      field('packId', 'Pack ID'),
      field('itemCode', 'Item Code'),
      field('itemName', 'Item Name'),
      field('lotNo', 'Lot No'),
      field('bagNo', 'Bag No', 'number'),
      field('packQty', 'Pack Qty', 'number'),
      field('uom', 'UOM'),
      field('supplier', 'Supplier'),
      field('invoiceNo', 'Invoice No'),
      field('receivedDate', 'Received Date', 'date'),
      field('status', 'Status', 'select', { options: ['AWAITING_INWARD', 'INWARDED', 'CANCELLED'] }),
      field('createdAt', 'Created At', 'datetime-local', { readOnly: true })
    ]
  },
  {
    key: 'inwardSession',
    title: 'Inward Sessions',
    model: 'InwardSession',
    path: 'inward-session',
    envKey: 'VITE_INWARD_SESSION_URL',
    defaultEndpoint: '/inward-session',
    idField: 'sessionId',
    description: 'Goods receipt scanning sessions.',
    fields: [
      field('sessionId', 'Session ID', 'text', { readOnly: true }),
      field('itemCode', 'Item Code'),
      field('lotNo', 'Lot No'),
      field('warehouse', 'Warehouse'),
      field('expectedBags', 'Expected Bags', 'number'),
      field('scannedPackIds', 'Scanned Pack IDs', 'tags'),
      field('status', 'Status', 'select', { options: ['ACTIVE', 'COMPLETED', 'CANCELLED'] }),
      field('createdAt', 'Created At', 'datetime-local', { readOnly: true }),
      field('updatedAt', 'Updated At', 'datetime-local', { readOnly: true })
    ]
  },
  {
    key: 'inward',
    title: 'Inward',
    model: 'Inward',
    path: 'inward',
    envKey: 'VITE_INWARD_URL',
    defaultEndpoint: '/inward',
    idField: 'id',
    description: 'Individual pack inward transactions.',
    fields: [
      field('id', 'ID', 'text', { readOnly: true }),
      field('packId', 'Pack ID'),
      field('itemCode', 'Item Code'),
      field('itemName', 'Item Name'),
      field('lotNo', 'Lot No'),
      field('bagNo', 'Bag No', 'number'),
      field('qty', 'Qty', 'number'),
      field('inwardTime', 'Inward Time', 'datetime-local'),
      field('warehouse', 'Warehouse')
    ]
  },
  {
    key: 'packBalance',
    title: 'Pack Balance',
    model: 'PackBalance',
    path: 'pack-balance',
    envKey: 'VITE_PACK_BALANCE_URL',
    defaultEndpoint: '/pack-balance',
    idField: 'packId',
    description: 'Running balance per pack.',
    fields: [
      field('packId', 'Pack ID'),
      field('itemCode', 'Item Code'),
      field('totalQty', 'Total Qty', 'number'),
      field('remainingQty', 'Remaining Qty', 'number')
    ]
  },
  {
    key: 'containerMaster',
    title: 'Container Master',
    model: 'ContainerMaster',
    path: 'container-master',
    envKey: 'VITE_CONTAINER_MASTER_URL',
    defaultEndpoint: '/container-master',
    idField: 'containerId',
    description: 'Reusable containers and current fill levels.',
    fields: [
      field('containerId', 'Container ID'),
      field('itemCode', 'Item Code'),
      field('itemName', 'Item Name'),
      field('capacity', 'Capacity', 'number'),
      field('currentQty', 'Current Qty', 'number'),
      field('uom', 'UOM')
    ]
  },
  {
    key: 'stockLedger',
    title: 'Stock Ledger',
    model: 'StockLedger',
    path: 'stock-ledger',
    envKey: 'VITE_STOCK_LEDGER_URL',
    defaultEndpoint: '/stock-ledger',
    idField: 'id',
    description: 'Append-only stock movement ledger.',
    fields: [
      field('id', 'ID', 'text', { readOnly: true }),
      field('itemCode', 'Item Code'),
      field('sourceId', 'Source ID'),
      field('transactionType', 'Transaction Type', 'select', { options: ['IN', 'OUT', 'ADJUSTMENT'] }),
      field('inQty', 'In Qty', 'number'),
      field('outQty', 'Out Qty', 'number'),
      field('balance', 'Balance', 'number'),
      field('reference', 'Reference'),
      field('timestamp', 'Timestamp', 'datetime-local')
    ]
  },
  {
    key: 'outward',
    title: 'Outward',
    model: 'Outward',
    path: 'outward',
    envKey: 'VITE_OUTWARD_URL',
    defaultEndpoint: '/outward',
    idField: 'id',
    description: 'Individual outward issue transactions.',
    fields: [
      field('id', 'ID', 'text', { readOnly: true }),
      field('indentId', 'Indent ID'),
      field('sourceId', 'Source ID'),
      field('sourceType', 'Source Type', 'select', { options: ['PACK', 'BULK', 'CONTAINER'] }),
      field('rmCode', 'RM Code'),
      field('qtyIssued', 'Qty Issued', 'number'),
      field('remarks', 'Remarks', 'textarea'),
      field('timestamp', 'Timestamp', 'datetime-local')
    ]
  }
];
