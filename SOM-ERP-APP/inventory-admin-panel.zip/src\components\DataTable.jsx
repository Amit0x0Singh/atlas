function formatValue(value) {
  if (value === null || value === undefined || value === '') return '-';
  if (Array.isArray(value)) return value.join(', ');
  if (typeof value === 'boolean') return value ? 'Yes' : 'No';
  if (typeof value === 'string' && /^\d{4}-\d{2}-\d{2}T/.test(value)) {
    return new Date(value).toLocaleString();
  }
  return String(value);
}

function getRowKey(record, resource, fallback) {
  if (Array.isArray(resource.idField)) {
    return resource.idField.map((field) => record[field]).join('-') || fallback;
  }

  return record[resource.idField] || fallback;
}

export default function DataTable({ resource, records, loading, onEdit, onDelete }) {
  if (loading) {
    return <div className="empty-state">Loading records...</div>;
  }

  if (!records.length) {
    return <div className="empty-state">No records found.</div>;
  }

  return (
    <div className="table-responsive data-table-wrap">
      <table className="table table-hover align-middle mb-0">
        <thead>
          <tr>
            {resource.fields.map((field) => (
              <th key={field.name}>{field.label}</th>
            ))}
            <th className="text-end">Actions</th>
          </tr>
        </thead>
        <tbody>
          {records.map((record, index) => (
            <tr key={getRowKey(record, resource, index)}>
              {resource.fields.map((field) => (
                <td key={field.name}>{formatValue(record[field.name])}</td>
              ))}
              <td className="text-end action-cell">
                <button className="btn btn-sm btn-outline-primary" onClick={() => onEdit(record)}>
                  Edit
                </button>
                <button className="btn btn-sm btn-outline-danger" onClick={() => onDelete(record)}>
                  Delete
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
